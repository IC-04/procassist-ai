# Literature Survey (LaTeX source)

**Inferring Business Processes from Desktop Operation Logs** — a literature, open-source and
industry survey for the "From Operation Logs to an Automation Proposal" assignment.

## Files

```
main.tex                     the document
references.bib               63 entries; each carries a verification status in its `note` field
figures/                     9 original TikZ / pgfplots figures, one file each
japanese-search-terms.txt    Japanese search terms in their original script (see note below)
Makefile                     `make` builds the PDF; `make clean` removes intermediates
```

## Building

```
make            # pdflatex -> bibtex -> pdflatex -> pdflatex
make clean      # remove auxiliary files
make distclean  # also remove the PDF
```

Or by hand:

```
pdflatex main && bibtex main && pdflatex main && pdflatex main
```

**On Overleaf:** Menu → Compiler = *pdfLaTeX*, Bibliography = *BibTeX*. Upload the whole
folder; no other setup is needed.

Requires a standard TeX Live installation. The only non-default packages used are
`natbib`, `cleveref`, `pgfplots`, `pdflscape`, `microtype`, `tabularx` and `booktabs`, all of
which ship with `texlive-latex-recommended` and `texlive-pictures`.

## Figures

All nine figures are **original diagrams prepared for this survey**. None reproduces a figure
from a source paper — reusing published figures in a submitted document is a copyright problem,
and the captions therefore state precisely what each diagram synthesises:

| File | What it is |
|---|---|
| `rpm_pipeline.tex` | The six-stage robotic process mining pipeline mapped onto the assignment's three steps. Original; stage sequence follows Leno et al. (2021). |
| `taxonomy_overview.tex` | Problem taxonomy organised by the assumption the assignment withholds (A1–A4). Original. |
| `segmentation_cases.tex` | The three segmentation difficulty cases plus a fourth row for this assignment. Rows 1–3 redrawn from the case taxonomy described by Agostinelli et al. (2021). |
| `leno_pipeline.tex` | Candidate-routine discovery from unsegmented UI logs, annotated with the authors' own stated failure conditions. Redrawn from the method description in Leno et al. (2020). |
| `rebmann_architecture.tex` | Unsupervised task identification and categorisation. Redrawn from the method description in Rebmann & van der Aa (2023). |
| `metric_behaviour.tex` | Schematic of how Pk and WindowDiff treat near-misses, false positives and misses. Original; illustrates the analysis in Pevzner & Hearst (2002). |
| `coverage_map.tex` | Subproblems mapped to the fields that address them, with gaps marked. Original. |
| `evidence_scale.tex` | Evaluation sizes of the closest published studies against this assignment's datasets. Original chart from event counts reported in the papers. |
| `validation_asymmetry.tex` | The Dataset A / Dataset B measurement asymmetry. Original. |

To edit a figure, edit its file — `main.tex` pulls each in with `\input` inside a `\resizebox`.

## Japanese text

The Japanese search terms live in `japanese-search-terms.txt` rather than in the document,
so that `main.tex` compiles with pdfLaTeX on any installation. The body text uses
transliterations with English glosses. To typeset the original script instead, add
`\usepackage{CJKutf8}` and wrap each term in `\begin{CJK}{UTF8}{min}…\end{CJK}`; this needs
Japanese CJK fonts, which Overleaf has but many local installations do not.

## Verification marks

Every source carries one of three marks, defined in §3 and used in Table 2 and Appendix A:

- ● full text or substantial content retrieved and read during the survey
- ○ abstract or landing page retrieved only
- △ existence, title and venue confirmed through indexes, but contents not retrieved

No △ source supports a central claim. The "Sources Requiring Further Verification" section
lists everything that resisted retrieval and every author list the retrieved records left
incomplete — check these against publisher records before formal submission.

## Placeholders to fill before submitting

- `[INSTITUTE / ORGANISATION]` on the title page.
